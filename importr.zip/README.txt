Importr README
------------
Written by Christian Cueni <chrigu [at]  trivialview [dot] ch>
http://www.trivialview.ch

Released under GNU Lesser General Public License (http://www.gnu.org/copyleft/lgpl.html)

Requires phpflickr by Dan Coulter
http://www.phpflickr.com

Importr allows one to import special tagged pictures from flickr in pixelpost.

CHANGELOG
---------

v0.65
changed an error in the db (thx to befamao). If you have v0.6 drop the importroptions table and replace the admin_importr.php
file.

v0.6
Possibility to define thumb origin (flickr thumbs or squares, or Pixelpost thumb) and picture size 
(flickr predefined sets).

v0.5
changed name to importr. 

added support for this GoogleMap addon: http://www.schonhose.nl/2008/02/01/pixelpost-addon-googlemap/
if it is present, geo data is added to the db.

v0.4
's are now ok for title and body. 

Pictures can be downloaded in original size and original file type.

v0.3
First version that is public available and can be refered to as demonstrator.


INSTALLATION
------------

1. Obtain phpFlickr from http://sourceforge.net/projects/phpflickr 

2. Apply for a flickr API key http://www.flickr.com/services/api/keys/

   Set up http://yoursite.com/path_to_pp/addons/importr/auth.php as callback script.

3. Make a directory called "importr" in pixelpost addons directory (pp_root/addons/importr/)

4. Now you need authenticate phpflickr scripts with syncr. You might want to read:

   http://phpflickr.com/docs/?page=auth or check phpFlickrs readme
   
   Anyway, enter the obtained API key and secret and change "permissions" to write in auth.php (line 9, 10 & 12).
   
   Enter the obtained API key and secret (line 12) in getToken.php and change permission in line 15 from read to write.
   
   Make sure you have the appropriate rights to run the scripts.
   
5. Copy phpflickr's "PEAR" directory, phpflickr.php, auth.php, getToken.php and to pp_root/addons/importr/

6. Run http://yoursite.com/path_to_pp/addons/importr/auth.php

   You should now be redirected to flickr and you have to authenticate.
   
   Now you should be redirected to your site. Run
   
   http://yoursite.com/path_to_pp/addons/importr/getToken.php
   
   Write down the token.
   
   Delete getToken.php from your webserver.
   
7. Enter your API key, secret and token in importr.php line 70 & 71.

8. Upload importr to pp_root/addons/importr/ directory and admin_importr.php to pp_root/addons/ directory.

9. your directory should now look like this:

   pp_root/addons/  ...
                  admin_importr.php
                  importr/
                       importr.php
                       phpflickr.php
                       auth.php
                       PEAR/..
                       
10. You should now find the importr addon in your pp addon section in the admin interface where you need to turn it on.


USAGE
-----

Please note that importr does download the original files from flickr. This means large pictures are not being
resized.

If everything went ok with the installation a importr tab should appear in the admin's pp Options section.

The following options appear: import tag, category prefix, flickr username, thumb and size.

import tag

This tag specifies which pictures should be imported from flickr. All pictures on your flickr account that have
this tag are being imported to pixelpost. Importr only downloads pictures where it was you that set the import tag.
After the import this tag will be deleted on flickr.

category prefix

With this prefix you control in what (pixelpost) category the imported photo goes in: If you choose "pp%" as 
prefix, all tags that start with "pp%" are considered as pixelpost categories where the part after the
prefix defines the category. An example: The tag "pp%snow" will go in pixelpost snow category. If the 
category does not exist, it is created. After the import this tag will be deleted on flickr.

flickr username

Your flickr username.

thumb

You can choose to import thumbnails genereated by flickr (square & thumbnail) or that Pixelpost
generates the thumbnails.

Check http://www.flickr.com/photos/yourusername/photoid/sizes/ for available sizes

size

Lets you decide the size the picture is imported from a pre-defined set (medium, large, original).
Please check if on http://www.flickr.com/photos/yourusername/photoid/sizes/ you have the option to
import the required size. Pictures that are for instance 600px are not available in large and result,
 if you choose large as option, in an empty file. So please make sure you got the right size.

All other flickr tags are imported as Pixelpost tags.


If you want to start an import you need to run http://yoursite.com/path_to_pp/addons/importr/importr.php manually
or you could make a cron job that runs the script everyday at a specific time.

If you're using the GoogleMap addon (http://www.schonhose.nl/2008/02/01/pixelpost-addon-googlemap/) and you're 
pictures on flickr are geotagged the geo information is added in Pixelpost as well.

Importr does not let you to import a picture twice. This data is stored in a database. If you want to delete a picture
and re-import it, please do not use the mass deletion mode as this does not change the aforementioned database. Just
delete the picture one by one.


KNOWN ISSUES
------------

This manual.

Importr builds a database with where the pictures IDs from pixelpost and flickr are stored. Importr first checks
if your picture is already is in the database. If this is the case the picture will not be imported. Importr
deletes entries from this database when you delete a picture. However, if pictures are being erased in mass mode
the database is not altered. Therefore it is not recommended to use mass mode when you want to delete pictures
that were imported by importr.

No handling of alt_body, alt_headline tags.

CSS of admin interface.

Please report other issues to <chrigu [at]  trivialview [dot] ch>.


OUTLOOK
-------

Integration of comments.



